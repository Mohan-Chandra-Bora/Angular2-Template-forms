import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';

import { EventService } from '../events/shared/event.service';

@Injectable()
export class EventListResolver implements Resolve<any> {
    constructor(private eventService: EventService) {

    }

    resolve() {
        // Usually we will have to subscribe to observable like for http.get
        // or else the method get do is not called, this will get called because of resolve and no need of subscribe
        return this.eventService.getEvents();
        // No need of .map as it is already done with the Observable in the service
        // return this.eventService.getEvents().map(events =>  events);
    }
}
