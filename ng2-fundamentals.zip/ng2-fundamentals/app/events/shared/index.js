"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./event.service'));
__export(require('./restricted-words.validator'));
__export(require('./duration.pipe'));
//# sourceMappingURL=index.js.map