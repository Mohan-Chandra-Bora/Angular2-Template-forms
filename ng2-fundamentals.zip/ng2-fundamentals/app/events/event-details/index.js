"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./event-details.component'));
// not used anymore-->export * from './event-route-activator.service';
__export(require('./create-session.component'));
__export(require('./session-list.component'));
__export(require('./upvote.component'));
__export(require('./voter.service'));
//# sourceMappingURL=index.js.map