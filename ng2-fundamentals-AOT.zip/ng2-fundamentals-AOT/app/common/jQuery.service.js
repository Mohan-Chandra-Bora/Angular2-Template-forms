import { OpaqueToken } from '@angular/core';
export var JQ_TOKEN = new OpaqueToken('jQuery');
//# sourceMappingURL=jQuery.service.js.map