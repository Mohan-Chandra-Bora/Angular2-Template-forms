import { OpaqueToken } from '@angular/core';
export var TOASTR_TOKEN = new OpaqueToken('toastr');
//# sourceMappingURL=toastr.service.js.map