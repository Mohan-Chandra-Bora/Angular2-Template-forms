import { Injectable } from '@angular/core';
import { Isession } from '../shared/index';
import { Observable } from 'rxjs/Observable';
import { Http, Headers, Response, RequestOptions} from '@angular/http';

@Injectable()
export class VoterService {
    constructor(private http:Http) {}
    addVoter(eventId:number, session:Isession, voterName) {
        session.voters.push(voterName);
        let headers = new Headers({'Content-Type':'application/json'});
        let options = new RequestOptions({headers:headers});
        let url = `/api/events/${eventId}/sessions/${session.id}/voters/${voterName}`;

        this.http.post(url, JSON.stringify({}),options).catch(this.handleErrors).subscribe();
    }
    deleteVoter(eventId:number, session:Isession, voterName) {
        session.voters = session.voters.filter(voter => voter !== voterName);

        this.http.delete(`/api/events/${eventId}/sessions/${session.id}/voters/${voterName}`).catch(this.handleErrors).subscribe();
    }
    userHasVoted(session:Isession, voterName) {
        return session.voters.some(voter => voter === voterName );
    }

    handleErrors(error:Response) {
        return Observable.throw(error.statusText);
    }
}
