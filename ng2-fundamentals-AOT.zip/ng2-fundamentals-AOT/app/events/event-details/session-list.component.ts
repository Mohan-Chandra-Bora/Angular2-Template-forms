import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Isession } from '../shared/index';
import { AuthService } from '../../user/auth.service';
import { VoterService } from './voter.service';
 
@Component({
    moduleId: module.id,
    selector: 'session-list',
    templateUrl: 'session-list.component.html'
})
export class SessionListComponent implements OnChanges {
@Input() sessions:Isession[];
@Input() filterBy:string;
@Input() sortBy:string;
@Input() eventId:number;
visibleSessions: Isession[]=[];

constructor(private auth:AuthService, private voterService:VoterService) {}

ngOnChanges(changes: SimpleChanges) {
        if(this.sessions) {
            this.filterSessions(this.filterBy);
            this.sortBy === 'name'? this.visibleSessions.sort(sortByNameAsc):this.visibleSessions.sort(sortByVotesDsc);
        }
    }

filterSessions(filterSession) {
    if(filterSession === 'all') {
        this.visibleSessions = this.sessions.slice(0);
    } else {
        this.visibleSessions = this.sessions.filter(sessions => sessions.level.toLocaleLowerCase() === filterSession);
    }
 }

 toggleVote(session:Isession) {
    if(this.userHasVoted(session)) {
        this.voterService.deleteVoter(this.eventId, session, this.auth.currentUser.userName);
    } else {
        this.voterService.addVoter(this.eventId, session, this.auth.currentUser.userName);
    }
    if(this.sortBy==='vote') {
        this.visibleSessions.sort(sortByVotesDsc);
    }
}

userHasVoted(session) {
    return this.voterService.userHasVoted(session, this.auth.currentUser.userName);
}

}

function sortByNameAsc(s1:Isession,s2:Isession) {
    if(s1.name > s2.name) {
        return 1;
    } else if(s1.name === s2.name) {
         return 0;
    } else {
        return -1;
    }
}

function sortByVotesDsc(v1:Isession, v2:Isession) {
    return v2.voters.length - v1.voters.length;
}
