var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from './shared/event.service';
export var CreateComponentEvent = (function () {
    function CreateComponentEvent(router, eventService) {
        this.router = router;
        this.eventService = eventService;
        this.isDirty = true;
    }
    CreateComponentEvent.prototype.saveEvent = function (formValues) {
        var _this = this;
        this.eventService.saveEvent(formValues).subscribe(function (event) {
            _this.router.navigate(['/events']);
            _this.isDirty = false;
        });
    };
    CreateComponentEvent.prototype.cancel = function () {
        this.router.navigate(['/events']);
    };
    CreateComponentEvent = __decorate([
        Component({
            moduleId: module.id,
            templateUrl: 'create-event.component.html',
            styles: ["\n    em { float:right; color:#E05C65; padding-left:10px; }\n    .error input { background-color:#E3C3C5; }\n    .error ::-webkit-input-placeholder { color:#999; }\n    .error ::-moz-placeholder { color:#999; }\n    .error :-moz-placeholder { color:#999; }\n    .error ::-ms-input-placeholder { color:#999; }\n  "]
        }), 
        __metadata('design:paramtypes', [Router, EventService])
    ], CreateComponentEvent);
    return CreateComponentEvent;
}());
//# sourceMappingURL=create-event.component.js.map