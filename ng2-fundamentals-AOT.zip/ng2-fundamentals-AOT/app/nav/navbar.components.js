var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { AuthService } from '../user/auth.service';
import { EventService } from '../events/index';
export var NavBarComponent = (function () {
    function NavBarComponent(authService, eventService) {
        this.authService = authService;
        this.eventService = eventService;
        this.searchTerm = '';
        this.foundSessions = [];
    }
    NavBarComponent.prototype.searchSessions = function (searchTerm) {
        var _this = this;
        this.eventService.searchSessions(searchTerm).subscribe(function (sessions) {
            _this.foundSessions = sessions;
            console.log(_this.foundSessions);
        });
    };
    NavBarComponent = __decorate([
        Component({
            moduleId: module.id,
            selector: 'nav-bar',
            templateUrl: 'navbar.components.html',
            styles: ["\n     .nav.navbar-nav {font-size: 15px;}\n     #searchForm {margin-right: 100px;}\n     @media (max-width: 1200px) {#searchForm {display:none}}\n     li > a.active { color: #F92974; }\n    "]
        }), 
        __metadata('design:paramtypes', [AuthService, EventService])
    ], NavBarComponent);
    return NavBarComponent;
}());
//# sourceMappingURL=navbar.components.js.map